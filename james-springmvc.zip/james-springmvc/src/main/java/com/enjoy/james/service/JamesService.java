package com.enjoy.james.service;

public interface JamesService {
    
    String query(String name, String age);
    
    String insert(String param);
    
    String update(String param);
}
