package com.enjoy.cap2.dao;


import org.springframework.stereotype.Repository;

@Repository
public class OrderDao {

}
