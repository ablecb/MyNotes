package com.enjoy.cap2.service;

import org.springframework.stereotype.Service;

@Service
public class OrderService {

}
