package com.enjoy.cap2.controller;

import org.springframework.stereotype.Controller;

@Controller
public class OrderController {

}
