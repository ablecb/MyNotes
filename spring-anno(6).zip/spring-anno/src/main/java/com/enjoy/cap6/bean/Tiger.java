package com.enjoy.cap6.bean;

public class Tiger {

}
