package com.enjoy.servlet;

public interface JamesService {

}
