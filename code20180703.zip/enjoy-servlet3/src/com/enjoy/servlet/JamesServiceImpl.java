package com.enjoy.servlet;

public class JamesServiceImpl implements JamesService {

}
