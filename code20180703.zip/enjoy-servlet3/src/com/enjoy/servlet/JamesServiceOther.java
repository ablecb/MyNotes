package com.enjoy.servlet;

public interface JamesServiceOther extends JamesService {

}
