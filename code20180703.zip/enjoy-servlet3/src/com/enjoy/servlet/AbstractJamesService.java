package com.enjoy.servlet;

public abstract class AbstractJamesService implements JamesService{

}
