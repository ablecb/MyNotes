package com.enjoy.service;

public abstract class AbstractJamesService implements JamesService {

}
