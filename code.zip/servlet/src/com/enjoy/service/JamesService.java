package com.enjoy.service;

public interface JamesService {

}

