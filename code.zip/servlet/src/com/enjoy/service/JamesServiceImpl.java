package com.enjoy.service;

public class JamesServiceImpl implements JamesService {

}
