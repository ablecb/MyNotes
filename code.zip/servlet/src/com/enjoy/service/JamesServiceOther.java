package com.enjoy.service;

public interface JamesServiceOther extends JamesService {

}
